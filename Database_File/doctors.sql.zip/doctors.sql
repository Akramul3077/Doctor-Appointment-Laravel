-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2022 at 05:49 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctors`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `appointment_no` bigint(20) NOT NULL,
  `appointment_date` date DEFAULT NULL,
  `doctor_id` bigint(20) NOT NULL,
  `patient_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_fee` bigint(20) NOT NULL,
  `paid_amount` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `appointment_no`, `appointment_date`, `doctor_id`, `patient_name`, `patient_phone`, `total_fee`, `paid_amount`, `created_at`, `updated_at`) VALUES
(1, 1, '2022-03-16', 1, 'Md. Hasan', '01854787742', 500, 500, '2022-03-14 23:14:43', '2022-03-14 23:14:43'),
(2, 2, '2022-03-16', 2, 'Md. Kamal Uddin', '01954787748', 450, 450, '2022-03-15 14:41:27', '2022-03-15 14:41:27'),
(3, 1647579103953, '2022-03-18', 1, 'Md. Rohim', '01918282826', 500, 500, '2022-03-17 22:51:44', '2022-03-17 22:51:44'),
(4, 1647580832087, '2022-03-19', 1, 'Md. Rohim', '01918282827', 500, 500, '2022-03-17 23:20:32', '2022-03-17 23:20:32'),
(5, 1647580903798, '2022-03-19', 1, 'Md. Sagor', '01918282828', 500, 500, '2022-03-17 23:21:44', '2022-03-17 23:21:44'),
(6, 1647581009790, '2022-03-20', 1, 'Md. Hasan', '01918282228', 500, 500, '2022-03-17 23:23:30', '2022-03-17 23:23:30'),
(7, 1647581232890, '2022-03-20', 2, 'Md. Kamal', '01918282328', 450, 450, '2022-03-17 23:27:13', '2022-03-17 23:27:13'),
(8, 1647581262507, '2022-03-20', 2, 'Md. Kamal', '01918282328', 450, 450, '2022-03-17 23:27:43', '2022-03-17 23:27:43'),
(9, 1647581296834, '2022-03-19', 2, 'Md. Rohim', '01918222826', 450, 450, '2022-03-17 23:28:17', '2022-03-17 23:28:17'),
(10, 1647581854827, '2022-03-23', 10, 'Md. Abdur Rahaman', '01918542826', 500, 500, '2022-03-17 23:37:35', '2022-03-17 23:37:35'),
(11, 1647582035258, '2022-03-19', 13, 'Md. Kobir', '01918282446', 450, 450, '2022-03-17 23:40:35', '2022-03-17 23:40:35'),
(12, 1647582322267, '2022-03-25', 7, 'Md. Abdur Rahaman', '01918282254', 500, 500, '2022-03-17 23:45:22', '2022-03-17 23:45:22'),
(13, 1647750026906, '2022-03-22', 2, 'Md. Rohim', '01918282826', 450, 450, '2022-03-19 22:20:27', '2022-03-19 22:20:27'),
(14, 1648210402183, '2022-03-25', 1, 'Hasan', '01918282826', 500, 500, '2022-03-25 06:13:22', '2022-03-25 06:13:22'),
(15, 1648210838242, '2022-03-25', 1, 'Md. Rohim', '01918282827', 500, 500, '2022-03-25 06:20:38', '2022-03-25 06:20:38'),
(16, 1648216456895, '2022-03-26', 6, 'Md. Abdur Rahaman', '01918282827', 450, 450, '2022-03-25 07:54:17', '2022-03-25 07:54:17'),
(17, 1648216503743, '2022-03-26', 6, 'Md. Kobir', '01918222826', 450, 450, '2022-03-25 07:55:03', '2022-03-25 07:55:03'),
(18, 1648216540317, '2022-03-26', 15, 'Md. Kobir', '01918282826', 450, 450, '2022-03-25 07:55:40', '2022-03-25 07:55:40'),
(19, 1648223753310, '2022-03-26', 1, 'Hasan', '01918282827', 500, 500, '2022-03-25 09:55:53', '2022-03-25 09:55:53'),
(20, 1648226445613, '2022-03-29', 3, 'Md. Kobir', '01918542826', 550, 550, '2022-03-25 10:40:45', '2022-03-25 10:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Endocrinologists', '2022-03-14 10:51:35', '2022-03-14 10:51:35'),
(2, 'Pulmonologists', '2022-03-14 10:51:35', '2022-03-14 10:51:35'),
(3, 'Infectious disease doctors', '2022-03-14 10:51:35', '2022-03-14 10:51:35'),
(4, 'General surgeons', '2022-03-14 10:51:35', '2022-03-14 10:51:35'),
(5, 'General surgeons', '2022-03-14 10:51:35', '2022-03-14 10:51:35'),
(6, 'Anesthesiologists', '2022-03-14 10:51:36', '2022-03-14 10:51:36'),
(7, 'Urologists', '2022-03-14 10:51:36', '2022-03-14 10:51:36'),
(8, 'Nephrologists', '2022-03-14 10:51:36', '2022-03-14 10:51:36'),
(9, 'Neurologists', '2022-03-14 10:51:36', '2022-03-14 10:51:36'),
(10, 'Endocrinologists', '2022-03-14 10:51:36', '2022-03-14 10:51:36');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department_id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `department_id`, `name`, `phone`, `fee`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dr. Rafiul Islam', '01712458738', 500, '2022-03-14 10:55:22', '2022-03-14 10:55:22'),
(2, 2, 'Dr. Habibur Rahaman', '01712458739', 450, '2022-03-14 10:55:45', '2022-03-14 10:55:45'),
(3, 4, 'Dr. Sariful Islam', '01712458734', 550, '2022-03-14 10:56:14', '2022-03-14 10:56:14'),
(4, 5, 'Dr. SorifulIslam', '01712458741', 500, '2022-03-14 23:11:45', '2022-03-14 23:11:45'),
(5, 7, 'Dr. Robiul Islam', '01712458854', 450, '2022-03-14 23:12:27', '2022-03-14 23:12:27'),
(6, 3, 'Dr. Mominul Hoq', '01712458145', 450, '2022-03-14 23:13:25', '2022-03-14 23:13:25'),
(7, 6, 'Dr. Rasedul Islam', '01712458147', 500, '2022-03-14 23:14:03', '2022-03-14 23:14:03'),
(8, 10, 'Dr. Mamunur Rahaman', '01712453887', 350, '2022-03-14 23:14:43', '2022-03-14 23:14:43'),
(9, 9, 'Dr. Foridur Rahaman', '01712458546', 500, '2022-03-14 23:15:23', '2022-03-14 23:15:23'),
(10, 8, 'Dr. Motiur Rahaman', '01712384587', 500, '2022-03-14 23:16:30', '2022-03-14 23:16:30'),
(11, 7, 'Dr. Robin', '01712457388', 450, '2022-03-15 08:00:37', '2022-03-15 08:00:37'),
(12, 1, 'Dr. Karimul Hoq', '01712458542', 500, '2022-03-16 07:29:57', '2022-03-16 07:29:57'),
(13, 4, 'Dr. Sohag', '01712587394', 450, '2022-03-16 07:30:57', '2022-03-16 07:30:57'),
(14, 5, 'Dr. Robin', '01712734588', 550, '2022-03-16 07:31:38', '2022-03-16 07:31:38'),
(15, 3, 'Dr. Kamal', '01712473858', 450, '2022-03-16 07:32:13', '2022-03-16 07:32:13');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_03_14_085706_create_doctors_table', 1),
(6, '2022_03_14_141741_create_departments_table', 1),
(7, '2022_03_14_162839_create_appointments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `doctors_phone_unique` (`phone`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
